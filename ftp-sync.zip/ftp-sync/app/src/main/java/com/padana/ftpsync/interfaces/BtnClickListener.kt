package com.padana.ftpsync.interfaces

interface BtnClickListener {
    fun onBtnClick(position: Int)
}