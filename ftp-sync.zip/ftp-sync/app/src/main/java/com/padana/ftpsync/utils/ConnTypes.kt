package com.padana.ftpsync.utils

object ConnTypes {
    val FTP: String = "ftp"
    val SFTP: String = "sftp"
}