package com.padana.ftpsync.interfaces

interface CheckBoxChanged {
    fun onCheckBoxChangedState(position: Int, isChecked: Boolean)
}